class Task6{
    public static void dynamicArray(int n) {
        int[] temp = new int[n];
        for (int i = 0; i < n; i++) {
            temp[i] = i;
        }
    }
}

// Time Complexity: O(n)