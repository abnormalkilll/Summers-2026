//Prefix Running Product:
//Input: int[] nums (e.g., [1, 2, 3, 4]).
//Requirement: Return a new array where result[i] = nums[0] * nums[1] * ... * nums[i] (e.g., [1, 2, 6, 24]).
//Constraint: O(N) Time and O(N) Output Space.

class Problem4{

    static void main() {

        int[] nums = {1, 2, 3, 4};
        int[] result = new int[nums.length];

        result[0] = nums[0];
        for (int i=1; i<nums.length; i++) {
            result[i] = result[i-1] * nums[i];
        }

    }

}

//Time Complexity: O(n)
//Auxiliary Space: O(n)