class Task3{
    public static void combinedLoop(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n; i++) {
            System.out.println(arr[i]);
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.println(arr[i] + " " + arr[j]);
            }
        }
    }
}

// Time Complexity: O(n2)