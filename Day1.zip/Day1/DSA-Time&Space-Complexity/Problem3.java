//Move All Zeroes to End:
//Input: int[] nums (e.g., [0, 1, 0, 3, 12]).
//Requirement: Shift all 0s to the end while maintaining the relative order of non-zero elements ([1, 3, 12, 0, 0]).
//Constraint: In-place modification, O(N) Time, and O(1) Extra Space.

class Problem3{

    static void main() {
        int[] nums = {0, 1, 0, 3, 12};
        shiftZeros(nums);
    }

    static void shiftZeros(int[] nums){
        int nonZeroIndex = 0;
        for (int i=0; i<nums.length; i++) {
            if (nums[i] != 0) {
                int temp = nums[i];
                nums[i] = nums[nonZeroIndex];
                nums[nonZeroIndex] = temp;
                nonZeroIndex++;
            }
        }
    }

}

//Time Complexity: O(n)
//Auxiliary Space: O(1)