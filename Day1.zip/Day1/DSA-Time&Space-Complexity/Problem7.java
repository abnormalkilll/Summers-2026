//Check If Array Is Sorted:
//Input: An array int[] nums.
//Requirement: Return true if sorted in non-decreasing order, false otherwise.
//Constraint: Strictly O(N) Time and O(1) Space with early exit on violation.

class Problem2{

    static void main() {
        int[] num1 = {2, 7, 3, 5};
        System.out.println(checkSorted(num1));
    }

    static boolean checkSorted(int[] nums){
        boolean flag = true;
        for (int i=0; i<nums.length-1; i++){
            if(nums[i]>nums[i+1]){
                flag = false;
                break;
            }
        }
        return flag;
    }

}


//Time Complexity: O(n)
//Auxiliary Space: O(1)