class Task7{
    public static void stepMultiply(int n) {
        for (int i = 1; i <= n; i = i * 2) {
            System.out.println(i);
        }
    }
}

// Time Complexity: O(log n)