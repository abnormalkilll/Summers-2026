//Find Second Largest:
//Input: An unsorted array int[] arr of size N>=2.
//Requirement: Return the second largest distinct number in the array.
//Constraint: Strictly O(N) Time and O(1) Auxiliary Space in a single pass (no sorting).

class Problem1{

    static void main() {

        int[] arr = {2, 7, 3, 5, 12};
        int largest = Integer.MIN_VALUE;
        int sLargest = Integer.MIN_VALUE;
        for (int i=0; i<arr.length; i++){
            if (arr[i]>largest) {
                sLargest = largest;
                largest = arr[i];
            } else if (arr[i]<largest && arr[i]>sLargest)
                sLargest = arr[i];
        }
        System.out.println(sLargest);

    }

}

//Time Complexity: O(n)
//Auxiliary Space: O(1)