class Task4{
    public static void dualInput(int[] a, int[] b) {
        for (int x : a) {
            for (int y : b) {
                System.out.println(x + " " + y);
            }
        }
    } 
}

// Time Complexity: O(a*b)