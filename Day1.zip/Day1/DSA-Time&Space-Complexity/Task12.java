class Task2{
    public static void halver(int n) {
        while (n > 1) {
            System.out.println(n);
            n = n / 2;
        }
    }
}

// Time Complexity: O(log n)