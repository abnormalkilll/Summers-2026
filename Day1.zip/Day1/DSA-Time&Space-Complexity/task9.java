class Task9{
    public static void squareRootLoop(int n) {
        for (int i = 0; i * i < n; i++) {
            System.out.println(i);
        }
    }
}

// Time Complexity: O(sqrt(n))
