class Task5{
    public static void constantArray(int n) {
        int[] temp = new int[500];
        for (int i = 0; i < 500; i++) {
            temp[i] = i * 2;
        }
    }
}

// Time Complexity: O(1)