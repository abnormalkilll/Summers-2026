//Count Even Digit Numbers:
//Input: int[] nums (e.g., [12, 345, 2, 6, 7896]).
//Requirement: Count and return how many numbers contain an even number of digits (Output: 2, because 12 and 7896 have 2 and 4 digits).
//Constraint: O(N x digits) Time and O(1) Auxiliary Space.

class Problem5{

    static void main() {

        int[] nums = {12, 345, 2, 6, 7896};
        int count = 0;
        for (int i=0; i<nums.length; i++) {
            int num = nums[i];
            int digits = 0;
            while (num > 0) {
                digits++;
                num = num / 10;
            }
            if (digits % 2 == 0)
                count++;
        }
        System.out.println(count);

    }

}

//Time Complexity: O(n x digits)
//Auxiliary Space: O(1)