class Task8{
    public static void nestedHalver(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = n; j > 1; j = j / 2) {
                System.out.println(i + " " + j);
            }
        }
    }
}

// Time Complexity: O(n log n)