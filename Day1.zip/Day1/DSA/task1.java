public static void mysteryOne(int[] arr) {
    int n = arr.length; // k
    for (int i = 0; i < n; i++) { // n
        for (int j = 0; j < n; j++) { // n
            System.out.println(arr[i] + ", " + arr[j]); // k
        }
    }
}

// Time Complexity: O(n2)