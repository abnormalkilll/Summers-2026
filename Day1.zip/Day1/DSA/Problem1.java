// LeetCode #1929 - Concatenation of Array
// Input: An integer array nums of length N.
// Output: An array ans of length 2N where ans[i] == nums[i] and ans[i + n] == nums[i] for 0 \le i < N.
// Target: Achieved in \mathcal{O}(N) Time and \mathcal{O}(N) Space.

public class Problem1{

    public static void main(String[] args){

        int[] nums = {1, 2, 3, 4};
        int[] ans = new int[2*nums.length];
        for(int i=0; i<nums.length; i++){
            ans[i] = nums[i];
            ans[i+nums.length] = nums[i];
        }

    }

}

// Time Complexity: O(n)