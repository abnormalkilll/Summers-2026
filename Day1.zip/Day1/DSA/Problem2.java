// Problem 2: LeetCode #1480 - Running Sum of 1d Array
// Input: An integer array nums (e.g., [1, 2, 3, 4]).
// Output: Running sum array runningSum[i] = sum(nums[0] ... nums[i]) (e.g., [1, 3, 6, 10]).
// Target: Achieved in O(N) Time.

public class Problem2{

    public static void main(String[] args){

        int[] nums = {1, 2, 3, 4};
        int[] runningSum = new int[nums.length];
        int sum = 0;
        for(int i=0; i<nums.length; i++){
            sum += nums[i];
            runningSum[i] = sum;
        }

    }

}

// Time Complexity: O(n)