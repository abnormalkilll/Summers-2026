public static int mysteryTwo(int n) {
    int count = 0;
    while (n > 1) {
        n = n / 2;
        count++;
    }
    return count;
}

// Time Complexity: O(log n)